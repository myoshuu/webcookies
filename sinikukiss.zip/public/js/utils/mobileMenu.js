function toogleBtn() {
  const menuMobile = document.querySelector(".menu-mobile");
  menuMobile.classList.toggle("open");
}
